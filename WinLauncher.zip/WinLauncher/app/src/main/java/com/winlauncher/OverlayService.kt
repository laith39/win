package com.winlauncher

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Point
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.EditText
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import kotlin.math.abs

private const val H_L = 1
private const val H_T = 2
private const val H_R = 4
private const val H_B = 8

/** عنصر قائمة منبثقة. */
class Act(val label: String, val run: () -> Unit)

private class Handle(val mask: Int, val v: View, val lp: WindowManager.LayoutParams)

/** شعار ويندوز (4 مربعات). */
class WinLogo(ctx: Context) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF60CDFF.toInt() }
    override fun onDraw(c: Canvas) {
        val s = minOf(width, height) * 0.42f
        val g = s * 0.07f
        val q = (s - g) / 2f
        val x0 = (width - s) / 2f
        val y0 = (height - s) / 2f
        for (i in 0..1) for (j in 0..1) {
            val l = x0 + i * (q + g)
            val t = y0 + j * (q + g)
            c.drawRect(l, t, l + q, t + q, p)
        }
    }
}

/**
 * خدمة العرض: أشرطة عناوين النوافذ ومقابض التحجيم + قائمة ابدأ + لوحة الإعدادات السريعة.
 * شريط المهام نفسه داخل MainActivity.
 */
class OverlayService : Service() {

    companion object {
        @Volatile
        var instance: OverlayService? = null
    }

    private lateinit var wm: WindowManager
    private val ui = Handler(Looper.getMainLooper())
    private var menu: View? = null
    private var quick: View? = null
    private var popup: View? = null
    private val chromes = HashMap<Win, Chrome>()
    private var scr = Point(2400, 1080)
    private val taskbarH: Int get() = dps(56, Cfg.tb)
    private val syncListener: () -> Unit = { refresh() }

    private val poll = object : Runnable {
        override fun run() {
            pollTasks()
            ui.postDelayed(this, 3000)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onCreate() {
        super.onCreate()
        instance = this
        Cfg.load(this)
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        startFg()
        WindowController.barH = dps(36, Cfg.wb)
        WindowController.minW = dp(220)
        WindowController.minH = dp(180)
        WindowController.minVisible = dp(80)
        measure()
        WindowController.listeners.add(syncListener)
        ui.postDelayed(poll, 3000)
    }

    override fun onDestroy() {
        ui.removeCallbacks(poll)
        closeAll()
        chromes.values.forEach { it.remove() }
        chromes.clear()
        WindowController.listeners.remove(syncListener)
        instance = null
        super.onDestroy()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        closeAll()
        measure()
        for (w in WindowController.wins) {
            WindowController.clamp(w)
            WindowController.apply(w)
        }
        refresh()
    }

    private fun startFg() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("win", "Win Launcher", NotificationManager.IMPORTANCE_MIN))
        val n = Notification.Builder(this, "win")
            .setSmallIcon(android.R.drawable.sym_def_app_icon)
            .setContentTitle("Win Launcher")
            .build()
        startForeground(1, n)
    }

    @Suppress("DEPRECATION")
    private fun measure() {
        val p = Point()
        wm.defaultDisplay.getRealSize(p)
        scr = p
        WindowController.area = Rect(0, 0, p.x, p.y - taskbarH)
    }

    private fun lp(w: Int, h: Int, g: Int, x: Int, y: Int, focus: Boolean = false): WindowManager.LayoutParams {
        var f = WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
        if (!focus) f = f or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        val p = WindowManager.LayoutParams(
            w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, f, PixelFormat.TRANSLUCENT
        )
        p.gravity = g
        p.x = x
        p.y = y
        p.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        return p
    }

    private fun panelBg(color: Int, radius: Int): GradientDrawable {
        val d = GradientDrawable()
        d.setColor(color)
        d.cornerRadius = dp(radius).toFloat()
        d.setStroke(1, 0x33FFFFFF)
        return d
    }

    private fun remove(v: View?) {
        if (v != null) try { wm.removeView(v) } catch (_: Exception) {}
    }

    /** يُستدعى بعد تغيير مقاييس الواجهة. */
    fun applyConfig() {
        closeAll()
        WindowController.barH = dps(36, Cfg.wb)
        measure()
        chromes.values.forEach { it.remove() }
        chromes.clear()
        for (w in WindowController.wins) {
            WindowController.clamp(w)
            WindowController.apply(w)
        }
        refresh()
    }

    fun closeAll() {
        hideMenu()
        hideQuick()
        hidePopup()
    }

    // ---------------------------------------------------------------- قائمة منبثقة عامة

    fun hidePopup() {
        remove(popup)
        popup = null
    }

    fun showPopup(title: String, items: List<Act>) {
        hidePopup()
        val panel = LinearLayout(this)
        panel.orientation = LinearLayout.VERTICAL
        panel.background = panelBg(0xF2262626.toInt(), 12)
        panel.setPadding(dp(8), dp(10), dp(8), dp(8))
        val t = TextView(this)
        t.text = title
        t.setTextColor(0xFF9A9A9A.toInt())
        t.textSize = 12f
        t.setPadding(dp(10), 0, dp(10), dp(6))
        panel.addView(t)
        val sv = ScrollView(this)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        sv.addView(col)
        panel.addView(sv, LinearLayout.LayoutParams(-1, 0, 1f))
        for (item in items) {
            val tv = TextView(this)
            tv.text = item.label
            tv.setTextColor(Color.WHITE)
            tv.textSize = 14f
            tv.setPadding(dp(12), dp(12), dp(12), dp(12))
            tv.tag = item
            tv.setOnClickListener { v ->
                hidePopup()
                (v.tag as? Act)?.run?.invoke()
            }
            col.addView(tv, LinearLayout.LayoutParams(-1, -2))
        }
        panel.setOnTouchListener { _, e ->
            if (e.action == MotionEvent.ACTION_OUTSIDE) hidePopup()
            false
        }
        val h = minOf(scr.y - dp(60), dp(60) + items.size * dp(44))
        val p = lp(dp(300), h, Gravity.CENTER, 0, 0, true)
        p.flags = p.flags or WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH
        wm.addView(panel, p)
        popup = panel
    }

    // ---------------------------------------------------------------- قائمة ابدأ

    fun hideMenu() {
        remove(menu)
        menu = null
    }

    fun toggleMenu() {
        if (menu != null) hideMenu() else showMenu()
    }

    private fun showMenu() {
        hideQuick()
        hidePopup()
        val w = minOf(scr.x - dp(16), dps(460, Cfg.mn))
        val h = minOf(scr.y - taskbarH - dp(24), dps(540, Cfg.mn))

        val panel = LinearLayout(this)
        panel.orientation = LinearLayout.VERTICAL
        panel.background = panelBg(0xF2202020.toInt(), 12)
        panel.setPadding(dp(14), dp(14), dp(14), dp(10))

        val search = EditText(this)
        search.hint = "ابحث عن تطبيق"
        search.setHintTextColor(0xFF9A9A9A.toInt())
        search.setTextColor(Color.WHITE)
        search.textSize = 14f
        search.isSingleLine = true
        val sbg = GradientDrawable()
        sbg.setColor(0xFF2D2D2D.toInt())
        sbg.cornerRadius = dp(20).toFloat()
        search.background = sbg
        search.setPadding(dp(16), dp(8), dp(16), dp(8))
        panel.addView(search, LinearLayout.LayoutParams(-1, -2))

        val content = LinearLayout(this)
        content.orientation = LinearLayout.VERTICAL
        val pinTitle = sectionTitle("المثبّتة")
        val pinGrid = GridLayout(this)
        pinGrid.columnCount = 5
        val allTitle = sectionTitle("كل التطبيقات")
        val allGrid = GridLayout(this)
        allGrid.columnCount = 5
        content.addView(pinTitle)
        content.addView(pinGrid)
        content.addView(allTitle)
        content.addView(allGrid)
        val sv = ScrollView(this)
        sv.addView(content)
        panel.addView(sv, LinearLayout.LayoutParams(-1, 0, 1f))

        val cellW = (w - dp(28)) / 5
        fun fill(q: String) {
            pinGrid.removeAllViews()
            allGrid.removeAllViews()
            val showPins = q.isEmpty()
            pinTitle.visibility = if (showPins) View.VISIBLE else View.GONE
            pinGrid.visibility = if (showPins) View.VISIBLE else View.GONE
            if (showPins) {
                AppRepo.list(this, Place.TASKBAR).mapNotNull { AppRepo.find(this, it) }
                    .forEach { pinGrid.addView(menuCell(it, cellW)) }
            }
            allTitle.text = if (showPins) "كل التطبيقات" else "النتائج"
            AppRepo.all(this).filter { it.label.contains(q, true) }.forEach { allGrid.addView(menuCell(it, cellW)) }
        }
        fill("")
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) { fill(s.toString().trim()) }
        })

        val foot = LinearLayout(this)
        foot.orientation = LinearLayout.HORIZONTAL
        foot.setPadding(dp(4), dp(8), dp(4), dp(2))
        val st = footBtn("⚙  اللانشر") {
            hideMenu()
            startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        val lock = footBtn("🔒  قفل") {
            hideMenu()
            Shell.async("input keyevent 26")
        }
        foot.addView(st, LinearLayout.LayoutParams(0, -2, 1f))
        foot.addView(lock, LinearLayout.LayoutParams(0, -2, 1f))
        panel.addView(foot)

        panel.setOnTouchListener { _, e ->
            if (e.action == MotionEvent.ACTION_OUTSIDE) hideMenu()
            false
        }

        val p = lp(w, h, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL, 0, taskbarH + dp(8), true)
        p.flags = p.flags or WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH
        p.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN
        wm.addView(panel, p)
        menu = panel
    }

    private fun sectionTitle(t: String): TextView {
        val tv = TextView(this)
        tv.text = t
        tv.setTextColor(Color.WHITE)
        tv.textSize = 13f
        tv.setPadding(dp(4), dp(12), 0, dp(6))
        return tv
    }

    private fun footBtn(t: String, click: () -> Unit): TextView {
        val tv = TextView(this)
        tv.text = t
        tv.setTextColor(0xFFCCCCCC.toInt())
        tv.textSize = 13f
        tv.setPadding(dp(6), dp(10), dp(6), dp(6))
        tv.setOnClickListener { click() }
        return tv
    }

    private fun menuCell(app: AppInfo, w: Int): View {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.gravity = Gravity.CENTER_HORIZONTAL
        c.setPadding(dp(2), dp(8), dp(2), dp(8))
        val iv = ImageView(this)
        iv.setImageDrawable(app.newIcon())
        c.addView(iv, LinearLayout.LayoutParams(dps(40, Cfg.mn), dps(40, Cfg.mn)))
        val tv = TextView(this)
        tv.text = app.label
        tv.setTextColor(Color.WHITE)
        tv.textSize = 11f * Cfg.mn
        tv.maxLines = 1
        tv.ellipsize = TextUtils.TruncateAt.END
        tv.gravity = Gravity.CENTER
        c.addView(tv, LinearLayout.LayoutParams(-1, -2))
        val glp = GridLayout.LayoutParams()
        glp.width = w
        c.layoutParams = glp
        c.setOnClickListener {
            hideMenu()
            WindowController.open(this, app)
        }
        c.setOnLongClickListener {
            val tb = AppRepo.has(this, Place.TASKBAR, app.pkg)
            val dk = AppRepo.has(this, Place.DESKTOP, app.pkg)
            showPopup(
                app.label,
                listOf(
                    Act(if (tb) "إلغاء التثبيت من شريط المهام" else "تثبيت في شريط المهام") {
                        AppRepo.set(this, Place.TASKBAR, app.pkg, !tb)
                        WindowController.notifyChange()
                    },
                    Act(if (dk) "إزالة من سطح المكتب" else "إضافة إلى سطح المكتب") {
                        AppRepo.set(this, Place.DESKTOP, app.pkg, !dk)
                        WindowController.notifyChange()
                    }
                )
            )
            true
        }
        return c
    }

    // ---------------------------------------------------------------- الإعدادات السريعة

    fun hideQuick() {
        remove(quick)
        quick = null
    }

    fun toggleQuick() {
        if (quick != null) hideQuick() else showQuick()
    }

    private fun showQuick() {
        hideMenu()
        hidePopup()
        val w = minOf(scr.x - dp(16), dps(380, Cfg.mn))
        val panel = LinearLayout(this)
        panel.orientation = LinearLayout.VERTICAL
        panel.background = panelBg(0xF2202020.toInt(), 12)
        panel.setPadding(dp(16), dp(16), dp(16), dp(16))

        val names = arrayOf("Wi-Fi", "بلوتوث", "وضع الطيران")
        val states = booleanArrayOf(false, false, false)
        val tiles = arrayOfNulls<TextView>(3)
        fun paint(i: Int) {
            val d = GradientDrawable()
            d.cornerRadius = dp(10).toFloat()
            d.setColor(if (states[i]) 0xFF0067C0.toInt() else 0xFF3A3A3A.toInt())
            tiles[i]?.background = d
        }
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        for (i in 0..2) {
            val t = TextView(this)
            t.text = names[i]
            t.setTextColor(Color.WHITE)
            t.textSize = 13f
            t.gravity = Gravity.CENTER
            t.setOnClickListener {
                states[i] = !states[i]
                paint(i)
                val en = if (states[i]) "enable" else "disable"
                val cmd = when (i) {
                    0 -> "svc wifi $en"
                    1 -> "svc bluetooth $en"
                    else -> "cmd connectivity airplane-mode $en"
                }
                Shell.async(cmd)
            }
            tiles[i] = t
            paint(i)
            val tl = LinearLayout.LayoutParams(0, dp(56), 1f)
            tl.marginEnd = dp(6)
            row.addView(t, tl)
        }
        panel.addView(row, LinearLayout.LayoutParams(-1, -2))

        Shell.async(
            "settings get global wifi_on; settings get global bluetooth_on; settings get global airplane_mode_on"
        ) { out ->
            val l = out.trim().lines()
            for (i in 0..2) {
                states[i] = l.getOrNull(i)?.trim() == "1"
                paint(i)
            }
        }

        // السطوع
        panel.addView(sectionTitle("السطوع"))
        val br = SeekBar(this)
        br.max = 255
        br.progress = Settings.System.getInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, 128)
        br.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            private var last = 0L
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                val now = SystemClock.uptimeMillis()
                if (fromUser && now - last > 150) {
                    last = now
                    Shell.async("settings put system screen_brightness_mode 0; settings put system screen_brightness $p")
                }
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {
                val p = s?.progress ?: return
                Shell.async("settings put system screen_brightness $p")
            }
        })
        panel.addView(br, LinearLayout.LayoutParams(-1, -2))

        // الصوت
        panel.addView(sectionTitle("الصوت"))
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val vol = SeekBar(this)
        vol.max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        vol.progress = am.getStreamVolume(AudioManager.STREAM_MUSIC)
        vol.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                if (fromUser) am.setStreamVolume(AudioManager.STREAM_MUSIC, p, 0)
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        panel.addView(vol, LinearLayout.LayoutParams(-1, -2))

        panel.setOnTouchListener { _, e ->
            if (e.action == MotionEvent.ACTION_OUTSIDE) hideQuick()
            false
        }
        val p = lp(w, -2, Gravity.BOTTOM or Gravity.LEFT, dp(8), taskbarH + dp(8), true)
        p.flags = p.flags or WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH
        wm.addView(panel, p)
        quick = panel
    }

    // ---------------------------------------------------------------- مزامنة النوافذ

    fun refresh() {
        val live = WindowController.wins.toSet()
        chromes.keys.filter { it !in live }.forEach { chromes.remove(it)?.remove() }
        for (w in WindowController.wins) {
            chromes.getOrPut(w) { Chrome(w) }.layout()
        }
    }

    private fun pollTasks() {
        if (WindowController.wins.isEmpty() || !Shell.ready()) return
        Shell.task {
            val ids = WindowController.tasks() ?: return@task
            ui.post {
                val gone = WindowController.wins.filter { it.taskId !in ids.keys }
                if (gone.isNotEmpty()) {
                    WindowController.wins.removeAll(gone.toSet())
                    WindowController.notifyChange()
                }
            }
        }
    }

    private fun btn(t: String, onClick: () -> Unit): TextView {
        val b = TextView(this)
        b.text = t
        b.setTextColor(Color.WHITE)
        b.textSize = 14f * Cfg.wb
        b.gravity = Gravity.CENTER
        b.layoutParams = LinearLayout.LayoutParams(dps(44, Cfg.wb), -1)
        b.setOnClickListener { onClick() }
        return b
    }

    private fun snapMenu(win: Win) {
        showPopup(
            "تقسيم النافذة",
            listOf(
                Act("النصف الأيسر") { WindowController.snap(win, "L") },
                Act("النصف الأيمن") { WindowController.snap(win, "R") },
                Act("النصف العلوي") { WindowController.snap(win, "T") },
                Act("النصف السفلي") { WindowController.snap(win, "B") },
                Act("الربع العلوي الأيسر") { WindowController.snap(win, "TL") },
                Act("الربع العلوي الأيمن") { WindowController.snap(win, "TR") },
                Act("الربع السفلي الأيسر") { WindowController.snap(win, "BL") },
                Act("الربع السفلي الأيمن") { WindowController.snap(win, "BR") }
            )
        )
    }

    /** شريط العنوان + 8 مقابض لتغيير الحجم من كل الجهات. */
    private inner class Chrome(val win: Win) {
        private val ctx: Context = this@OverlayService
        private val e = dp(22)
        private val grip = dp(30)
        private val bar = LinearLayout(ctx)
        private val barLp = lp(win.rect.width(), WindowController.barH, Gravity.TOP or Gravity.START, win.rect.left, win.rect.top)
        private val handles = ArrayList<Handle>()
        private var added = false
        private var lastApply = 0L
        private var dX = 0f
        private var dY = 0f
        private var sL = 0
        private var sT = 0
        private var wasMax = false
        private var moved = false
        private val start = Rect()

        init {
            bar.orientation = LinearLayout.HORIZONTAL
            bar.gravity = Gravity.CENTER_VERTICAL
            bar.layoutDirection = View.LAYOUT_DIRECTION_LTR
            val bg = GradientDrawable()
            bg.setColor(0xFF2B2B2B.toInt())
            val r = dp(8).toFloat()
            bg.cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f)
            bar.background = bg

            val icon = ImageView(ctx)
            icon.setImageDrawable(win.app.newIcon())
            val ilp = LinearLayout.LayoutParams(dps(18, Cfg.wb), dps(18, Cfg.wb))
            ilp.marginStart = dp(10)
            ilp.marginEnd = dp(8)
            bar.addView(icon, ilp)

            val title = TextView(ctx)
            title.text = win.app.label
            title.setTextColor(Color.WHITE)
            title.textSize = 12f * Cfg.wb
            title.maxLines = 1
            title.ellipsize = TextUtils.TruncateAt.END
            bar.addView(title, LinearLayout.LayoutParams(0, -2, 1f))

            bar.addView(btn("—") { WindowController.minimize(win) })
            val maxBtn = btn("▢") { WindowController.toggleMax(win) }
            maxBtn.setOnLongClickListener { snapMenu(win); true }
            bar.addView(maxBtn)
            bar.addView(btn("✕") { WindowController.close(win) })

            bar.setOnTouchListener { _, ev -> onBarTouch(ev) }

            val masks = intArrayOf(H_L, H_T, H_R, H_B, H_L or H_T, H_T or H_R, H_L or H_B, H_R or H_B)
            for (m in masks) {
                val v = View(ctx)
                if (m == (H_R or H_B)) {
                    val gbg = GradientDrawable()
                    gbg.setColor(0x30FFFFFF)
                    gbg.cornerRadii = floatArrayOf(0f, 0f, 0f, 0f, dp(8).toFloat(), dp(8).toFloat(), 0f, 0f)
                    v.background = gbg
                } else {
                    v.setBackgroundColor(0x01000000)
                }
                v.setOnTouchListener { _, ev -> onHandleTouch(m, ev) }
                handles.add(Handle(m, v, lp(e, e, Gravity.TOP or Gravity.START, 0, 0)))
            }
        }

        private fun onBarTouch(ev: MotionEvent): Boolean {
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    dX = ev.rawX; dY = ev.rawY
                    sL = win.rect.left; sT = win.rect.top
                    wasMax = win.maximized
                    moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    if (wasMax) {
                        if (abs(ev.rawX - dX) > dp(8) || abs(ev.rawY - dY) > dp(8)) {
                            // سحب نافذة مكبّرة: نعيدها لحجمها السابق
                            val rs = win.restore
                            if (rs != null) win.rect.set(0, 0, rs.width(), rs.height())
                            win.maximized = false
                            win.restore = null
                            wasMax = false
                            moved = true
                            win.rect.offsetTo((ev.rawX - win.rect.width() / 2f).toInt(), 0)
                            sL = win.rect.left; sT = win.rect.top
                            dX = ev.rawX; dY = ev.rawY
                            layout()
                            WindowController.apply(win)
                        }
                    } else {
                        moved = true
                        val a = WindowController.area
                        val l = clampI(sL + (ev.rawX - dX).toInt(), -(win.rect.width() - WindowController.minVisible), a.right - WindowController.minVisible)
                        val t = clampI(sT + (ev.rawY - dY).toInt(), 0, a.bottom - WindowController.barH)
                        win.rect.offsetTo(l, t)
                        layoutBar()
                        throttled()
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (moved && !wasMax) {
                        layout()
                        val sw = WindowController.area.right
                        when {
                            ev.rawX <= dp(6) -> WindowController.snap(win, "L")
                            ev.rawX >= sw - dp(6) -> WindowController.snap(win, "R")
                            ev.rawY <= dp(6) -> WindowController.toggleMax(win)
                            else -> WindowController.apply(win)
                        }
                    }
                }
            }
            return true
        }

        private fun onHandleTouch(m: Int, ev: MotionEvent): Boolean {
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    dX = ev.rawX; dY = ev.rawY
                    start.set(win.rect)
                }
                MotionEvent.ACTION_MOVE -> {
                    resizeBy(m, (ev.rawX - dX).toInt(), (ev.rawY - dY).toInt())
                    layoutBar()
                    throttled()
                }
                MotionEvent.ACTION_UP -> {
                    layout()
                    WindowController.apply(win)
                }
            }
            return true
        }

        private fun resizeBy(m: Int, dx: Int, dy: Int) {
            val n = Rect(start)
            val minW = WindowController.minW
            val minH = WindowController.minH
            if ((m and H_L) != 0) n.left = clampI(start.left + dx, start.left - 4000, start.right - minW)
            if ((m and H_R) != 0) n.right = maxOf(start.right + dx, n.left + minW)
            if ((m and H_T) != 0) n.top = clampI(start.top + dy, 0, start.bottom - minH)
            if ((m and H_B) != 0) n.bottom = maxOf(start.bottom + dy, n.top + minH)
            win.maximized = false
            win.restore = null
            win.rect.set(n)
        }

        /** الدمج داخل WindowController.apply يمنع تراكم الطلبات، فلا حاجة لتأخير. */
        private fun throttled() {
            WindowController.apply(win)
        }

        /** أثناء السحب نحدّث الشريط فقط (استدعاء واحد) ونؤجل المقابض حتى الإفلات. */
        fun layoutBar() {
            if (!added) return
            val r = win.rect
            barLp.x = r.left
            barLp.y = r.top
            barLp.width = r.width()
            wm.updateViewLayout(bar, barLp)
        }

        private fun place(h: Handle) {
            val r = win.rect
            val g = when (h.mask) {
                H_L -> intArrayOf(r.left - e, r.top, e, r.height())
                H_R -> intArrayOf(r.right, r.top, e, r.height())
                H_T -> intArrayOf(r.left, r.top - e, r.width(), e)
                H_B -> intArrayOf(r.left, r.bottom, r.width(), e)
                H_L or H_T -> intArrayOf(r.left - e, r.top - e, e, e)
                H_T or H_R -> intArrayOf(r.right, r.top - e, e, e)
                H_L or H_B -> intArrayOf(r.left - e, r.bottom, e, e)
                else -> intArrayOf(r.right - grip, r.bottom - grip, grip, grip)
            }
            h.lp.x = g[0]
            h.lp.y = g[1]
            h.lp.width = g[2]
            h.lp.height = g[3]
        }

        fun layout() {
            if (win.minimized) {
                remove()
                return
            }
            val r = win.rect
            barLp.x = r.left
            barLp.y = r.top
            barLp.width = r.width()
            for (h in handles) place(h)
            if (!added) {
                wm.addView(bar, barLp)
                for (h in handles) wm.addView(h.v, h.lp)
                added = true
            } else {
                wm.updateViewLayout(bar, barLp)
                for (h in handles) wm.updateViewLayout(h.v, h.lp)
            }
        }

        fun remove() {
            if (!added) return
            try { wm.removeView(bar) } catch (_: Exception) {}
            for (h in handles) try { wm.removeView(h.v) } catch (_: Exception) {}
            added = false
        }
    }
}
