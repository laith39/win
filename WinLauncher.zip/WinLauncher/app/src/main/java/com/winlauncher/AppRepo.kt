package com.winlauncher

import android.content.Context
import android.content.Intent
import android.graphics.drawable.Drawable

data class AppInfo(val label: String, val pkg: String, val activity: String, val icon: Drawable) {
    val component: String get() = "$pkg/$activity"
}

fun AppInfo.newIcon(): Drawable = icon.constantState?.newDrawable()?.mutate() ?: icon

/** مكانان مستقلان لتثبيت التطبيقات. */
enum class Place(val key: String) { TASKBAR("tb"), DESKTOP("dk") }

object AppRepo {
    private var cache: List<AppInfo>? = null

    fun all(ctx: Context, refresh: Boolean = false): List<AppInfo> {
        if (!refresh) cache?.let { return it }
        val pm = ctx.packageManager
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val list = pm.queryIntentActivities(i, 0)
            .map { AppInfo(it.loadLabel(pm).toString(), it.activityInfo.packageName, it.activityInfo.name, it.loadIcon(pm)) }
            .filter { it.pkg != ctx.packageName }
            .sortedBy { it.label.lowercase() }
        cache = list
        return list
    }

    fun find(ctx: Context, pkg: String): AppInfo? = all(ctx).find { it.pkg == pkg }

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("win", Context.MODE_PRIVATE)

    fun list(ctx: Context, place: Place): List<String> {
        val p = prefs(ctx)
        if (!p.contains(place.key)) {
            val d = all(ctx).take(6).map { it.pkg }
            p.edit().putString(place.key, d.joinToString(",")).apply()
            return d
        }
        return p.getString(place.key, "")!!.split(",").filter { it.isNotEmpty() }
    }

    fun has(ctx: Context, place: Place, pkg: String): Boolean = list(ctx, place).contains(pkg)

    fun set(ctx: Context, place: Place, pkg: String, on: Boolean) {
        val l = list(ctx, place).toMutableList()
        l.remove(pkg)
        if (on) l.add(pkg)
        prefs(ctx).edit().putString(place.key, l.joinToString(",")).apply()
    }

    fun toggle(ctx: Context, place: Place, pkg: String): Boolean {
        val on = !has(ctx, place, pkg)
        set(ctx, place, pkg, on)
        return on
    }
}
