package com.winlauncher

import android.graphics.Rect
import android.os.IBinder
import org.lsposed.hiddenapibypass.HiddenApiBypass
import rikka.shizuku.ShizukuBinderWrapper
import rikka.shizuku.SystemServiceHelper
import java.lang.reflect.Method

/** استدعاء IActivityTaskManager.resizeTask مباشرة عبر Shizuku: أسرع بكثير من أمر am. */
object Atm {
    private var svc: Any? = null
    private var method: Method? = null
    @Volatile private var failed = false

    @Synchronized
    private fun init(): Boolean {
        if (svc != null) return true
        if (failed) return false
        return try {
            HiddenApiBypass.addHiddenApiExemptions("L")
            val raw = SystemServiceHelper.getSystemService("activity_task")
            val wrapped = ShizukuBinderWrapper(raw)
            val stub = Class.forName("android.app.IActivityTaskManager\$Stub")
            val obj = stub.getMethod("asInterface", IBinder::class.java).invoke(null, wrapped)
            val intT = Int::class.javaPrimitiveType
            val m = Class.forName("android.app.IActivityTaskManager")
                .getMethod("resizeTask", intT, Rect::class.java, intT)
            svc = obj
            method = m
            true
        } catch (t: Throwable) {
            failed = true
            false
        }
    }

    /** true إذا نجح الاستدعاء المباشر. mode 4 = RESIZE_MODE_FORCED مثل am task resize. */
    fun resize(taskId: Int, r: Rect, mode: Int = 4): Boolean {
        if (!init()) return false
        return try {
            method!!.invoke(svc, taskId, r, mode)
            true
        } catch (t: Throwable) {
            false
        }
    }
}
