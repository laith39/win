package com.winlauncher

import android.content.Context
import android.graphics.Rect
import android.widget.Toast
import java.util.concurrent.atomic.AtomicBoolean

/** rect = النافذة كاملة بما فيها شريط العنوان (الذي نرسمه نحن). */
class Win(
    val app: AppInfo,
    var taskId: Int,
    val rect: Rect,
    var maximized: Boolean = false,
    var restore: Rect? = null,
    var minimized: Boolean = false
) {
    val pending = AtomicBoolean(false)
}

object WindowController {
    val wins = mutableListOf<Win>()
    val listeners = mutableListOf<() -> Unit>()
    var area = Rect(0, 0, 1000, 1000)
    var barH = 0
    var minW = 300
    var minH = 300
    var minVisible = 100

    private val taskRe = Regex("""Task(?:Record)?\{[0-9a-f]+ #(\d+)[^}]*?A=(?:\d+:)?([\w.]+)""")

    fun notifyChange() {
        listeners.toList().forEach { it() }
    }

    fun ensureFreeform() {
        Shell.async(
            "settings put global enable_freeform_support 1; " +
                "settings put global force_resizable_activities 1; " +
                "settings put global freeform_window_management 1"
        )
    }

    /** خريطة taskId -> package. من خيط خلفي. */
    fun tasks(): Map<Int, String>? {
        val out = Shell.run("dumpsys activity activities")
        if (out.startsWith("ERR")) return null
        val m = HashMap<Int, String>()
        for (r in taskRe.findAll(out)) m[r.groupValues[1].toInt()] = r.groupValues[2]
        return m
    }

    private fun findTask(pkg: String): Int {
        val t = tasks() ?: return -1
        return t.filter { it.value == pkg }.keys.maxOrNull() ?: -1
    }

    fun open(ctx: Context, app: AppInfo) {
        if (!Shell.ready()) {
            Toast.makeText(ctx, "Shizuku غير جاهز", Toast.LENGTH_SHORT).show()
            return
        }
        val existing = wins.find { it.app.pkg == app.pkg }
        if (existing != null) {
            if (existing.minimized) restore(existing) else focus(existing)
            return
        }
        val n = wins.size % 5
        val w = (area.width() * 0.6f).toInt().coerceAtLeast(minW)
        val h = (area.height() * 0.7f).toInt().coerceAtLeast(minH)
        val l = clampI(area.left + 40 + n * 60, area.left, area.right - w)
        val t = clampI(area.top + 20 + n * 50, area.top, area.bottom - h)
        val rect = Rect(l, t, l + w, t + h)

        Shell.task {
            Shell.run("am start -n ${app.component} --windowingMode 5")
            var id = -1
            for (i in 0 until 8) {
                Thread.sleep(400)
                id = findTask(app.pkg)
                if (id >= 0) break
            }
            Shell.main.post {
                if (id < 0) {
                    Toast.makeText(ctx, "تعذر فتح ${app.label} كنافذة", Toast.LENGTH_SHORT).show()
                } else {
                    val win = Win(app, id, rect)
                    clamp(win)
                    wins.add(win)
                    apply(win)
                    notifyChange()
                }
            }
        }
    }

    fun focus(w: Win) {
        Shell.async("am start -n ${w.app.component} -f 0x00020000 --windowingMode 5")
    }

    fun bringAllFront() {
        wins.filter { !it.minimized }.forEach { focus(it) }
    }

    /** يدمج الطلبات: ينفذ آخر إحداثيات فقط حتى لا يتراكم الطابور أثناء السحب. */
    fun apply(w: Win) {
        if (w.pending.getAndSet(true)) return
        Shell.task {
            w.pending.set(false)
            val r = Rect(w.rect)
            if (w.minimized) r.offsetTo(20000, 20000)
            Shell.run("am task resize ${w.taskId} ${r.left} ${r.top + barH} ${r.right} ${r.bottom}")
        }
    }

    fun close(w: Win) {
        Shell.async("am force-stop ${w.app.pkg}")
        wins.remove(w)
        notifyChange()
    }

    fun minimize(w: Win) {
        w.minimized = true
        apply(w)
        notifyChange()
    }

    fun restore(w: Win) {
        w.minimized = false
        apply(w)
        focus(w)
        notifyChange()
    }

    fun toggleMax(w: Win) {
        if (!w.maximized) {
            w.restore = Rect(w.rect)
            w.rect.set(area)
            w.maximized = true
        } else {
            w.restore?.let { w.rect.set(it) }
            w.restore = null
            w.maximized = false
        }
        apply(w)
        notifyChange()
    }

    /** تقسيم الشاشة: L R T B TL TR BL BR */
    fun snap(w: Win, mode: String) {
        val a = area
        val mx = a.centerX()
        val my = a.centerY()
        val r = when (mode) {
            "L" -> Rect(a.left, a.top, mx, a.bottom)
            "R" -> Rect(mx, a.top, a.right, a.bottom)
            "T" -> Rect(a.left, a.top, a.right, my)
            "B" -> Rect(a.left, my, a.right, a.bottom)
            "TL" -> Rect(a.left, a.top, mx, my)
            "TR" -> Rect(mx, a.top, a.right, my)
            "BL" -> Rect(a.left, my, mx, a.bottom)
            else -> Rect(mx, my, a.right, a.bottom)
        }
        if (!w.maximized) w.restore = Rect(w.rect)
        w.rect.set(r)
        w.maximized = true
        w.minimized = false
        apply(w)
        notifyChange()
    }

    /** تحجيم حر: نحافظ فقط على الحد الأدنى للحجم وبقاء شريط العنوان ظاهراً. */
    fun clamp(w: Win) {
        val r = w.rect
        val ww = maxOf(r.width(), minW)
        val hh = maxOf(r.height(), minH)
        val l = clampI(r.left, -(ww - minVisible), area.right - minVisible)
        val t = clampI(r.top, 0, area.bottom - barH)
        r.set(l, t, l + ww, t + hh)
    }
}
