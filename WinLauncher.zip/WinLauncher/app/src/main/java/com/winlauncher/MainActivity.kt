package com.winlauncher

import android.app.Activity
import android.app.AlertDialog
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextClock
import android.widget.TextView
import android.widget.Toast
import rikka.shizuku.Shizuku
import java.io.File
import java.io.FileOutputStream

class MainActivity : Activity() {

    private lateinit var root: FrameLayout
    private lateinit var bg: ImageView
    private lateinit var desk: GridLayout
    private lateinit var card: LinearLayout
    private lateinit var tbRow: LinearLayout
    private lateinit var batt: TextView

    private val tbH: Int get() = dp(56)
    private val taskListener: () -> Unit = {
        refreshTaskbar()
        loadDesk()
    }
    private val permL = Shizuku.OnRequestPermissionResultListener { _, _ -> runOnUiThread { checkSetup() } }
    private val binderL = Shizuku.OnBinderReceivedListener { runOnUiThread { checkSetup() } }
    private val battRx = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) { showBatt(i) }
    }

    private val wallFile: File get() = File(filesDir, "wallpaper.jpg")
    private val prefs get() = getSharedPreferences("win", MODE_PRIVATE)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val a = window.attributes
        a.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        window.attributes = a

        root = FrameLayout(this)
        bg = ImageView(this)
        bg.scaleType = ImageView.ScaleType.CENTER_CROP
        root.addView(bg, FrameLayout.LayoutParams(-1, -1))

        // أيقونات سطح المكتب: عمود عمودي على اليمين مثل هايبر درويد
        desk = GridLayout(this)
        desk.orientation = GridLayout.VERTICAL
        desk.layoutDirection = View.LAYOUT_DIRECTION_RTL
        desk.setPadding(dp(8), dp(12), dp(8), 0)
        root.addView(desk, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.RIGHT))

        buildTaskbar()

        card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        val cbg = GradientDrawable()
        cbg.setColor(0xEE202020.toInt())
        cbg.cornerRadius = dp(14).toFloat()
        card.background = cbg
        card.setPadding(dp(16), dp(12), dp(16), dp(12))
        root.addView(card, FrameLayout.LayoutParams(dp(320), -2, Gravity.CENTER))

        root.setOnLongClickListener { showMainMenu(); true }
        setContentView(root)
        immersive()

        // إذا ظهر أي شريط للنظام نخفيه من جديد
        @Suppress("DEPRECATION")
        window.decorView.setOnSystemUiVisibilityChangeListener {
            Shell.main.postDelayed({ immersive() }, 1200)
        }

        WindowController.listeners.add(taskListener)
        Shizuku.addRequestPermissionResultListener(permL)
        Shizuku.addBinderReceivedListenerSticky(binderL)
    }

    /** ملء الشاشة الكامل: إخفاء شريط الحالة وشريط التنقل. */
    @Suppress("DEPRECATION")
    private fun immersive() {
        if (Build.VERSION.SDK_INT >= 30) {
            window.setDecorFitsSystemWindows(false)
            window.insetsController?.let {
                it.hide(WindowInsets.Type.statusBars() or WindowInsets.Type.navigationBars())
                it.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        }
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            immersive()
            // عند الضغط على اللانشر ننعش النوافذ لتبقى فوقه
            if (WindowController.wins.any { !it.minimized }) {
                Shell.main.postDelayed({ WindowController.bringAllFront() }, 250)
            }
        }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        loadDesk()
    }

    override fun onDestroy() {
        WindowController.listeners.remove(taskListener)
        Shizuku.removeRequestPermissionResultListener(permL)
        Shizuku.removeBinderReceivedListener(binderL)
        super.onDestroy()
    }

    override fun onResume() {
        super.onResume()
        AppRepo.all(this, true)
        checkSetup()
        loadBg()
        loadDesk()
        refreshTaskbar()
        showBatt(registerReceiver(battRx, IntentFilter(Intent.ACTION_BATTERY_CHANGED)))
    }

    override fun onPause() {
        try { unregisterReceiver(battRx) } catch (_: Exception) {}
        super.onPause()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        OverlayService.instance?.closeAll()
    }

    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        // لانشر: لا نغلق شيئاً
    }

    // ---------------------------------------------------------------- شريط المهام (داخل التطبيق فقط)

    private fun buildTaskbar() {
        val tb = FrameLayout(this)
        tb.setBackgroundColor(0xF0262626.toInt())
        root.addView(tb, FrameLayout.LayoutParams(-1, tbH, Gravity.BOTTOM))

        tbRow = LinearLayout(this)
        tbRow.orientation = LinearLayout.HORIZONTAL
        tbRow.gravity = Gravity.CENTER_VERTICAL
        tbRow.layoutDirection = View.LAYOUT_DIRECTION_RTL
        tb.addView(tbRow, FrameLayout.LayoutParams(-2, -1, Gravity.CENTER_HORIZONTAL))

        // اليسار: إشعارات + بطارية + ساعة (الضغط على البطارية/الساعة يفتح الإعدادات السريعة)
        val tray = LinearLayout(this)
        tray.orientation = LinearLayout.HORIZONTAL
        tray.gravity = Gravity.CENTER_VERTICAL
        tray.layoutDirection = View.LAYOUT_DIRECTION_LTR
        tray.setOnClickListener { toggleQuick() }

        val bell = TextView(this)
        bell.text = "🔔"
        bell.textSize = 16f
        bell.setPadding(dp(12), 0, dp(8), 0)
        bell.gravity = Gravity.CENTER
        bell.setOnClickListener { Shell.async("cmd statusbar expand-notifications") }
        tray.addView(bell, LinearLayout.LayoutParams(-2, -1))

        batt = TextView(this)
        batt.text = "🔋"
        batt.setTextColor(Color.WHITE)
        batt.textSize = 12f
        batt.gravity = Gravity.CENTER
        batt.setPadding(dp(4), 0, dp(10), 0)
        tray.addView(batt, LinearLayout.LayoutParams(-2, -1))

        val clock = TextClock(this)
        clock.format12Hour = "h:mm a\nd/M/yyyy"
        clock.format24Hour = "HH:mm\nd/M/yyyy"
        clock.setTextColor(Color.WHITE)
        clock.textSize = 11f
        clock.gravity = Gravity.CENTER
        clock.setPadding(dp(4), 0, dp(10), 0)
        tray.addView(clock, LinearLayout.LayoutParams(-2, -1))

        tb.addView(tray, FrameLayout.LayoutParams(-2, -1, Gravity.LEFT))
    }

    private fun showBatt(i: Intent?) {
        if (i == null) return
        val l = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        batt.text = "🔋 $l%"
    }

    private fun needService(): OverlayService? {
        val s = OverlayService.instance
        if (s == null) Toast.makeText(this, "فعّل صلاحية العرض فوق التطبيقات أولاً", Toast.LENGTH_SHORT).show()
        return s
    }

    private fun toggleMenu() { needService()?.toggleMenu() }
    private fun toggleQuick() { needService()?.toggleQuick() }

    private fun refreshTaskbar() {
        tbRow.removeAllViews()

        val logo = WinLogo(this)
        logo.setOnClickListener { toggleMenu() }
        tbRow.addView(logo, LinearLayout.LayoutParams(dp(48), dp(48)))

        val s = TextView(this)
        s.text = "🌤   بحث"
        s.setTextColor(0xFFDDDDDD.toInt())
        s.textSize = 14f
        s.gravity = Gravity.CENTER_VERTICAL
        s.setPadding(dp(16), 0, dp(18), 0)
        val sb = GradientDrawable()
        sb.setColor(0xFF3B3B3B.toInt())
        sb.cornerRadius = dp(20).toFloat()
        s.background = sb
        s.setOnClickListener { toggleMenu() }
        val slp = LinearLayout.LayoutParams(dp(200), dp(40))
        slp.marginStart = dp(6)
        slp.marginEnd = dp(6)
        tbRow.addView(s, slp)

        val gear = TextView(this)
        gear.text = "⚙"
        gear.setTextColor(0xFFCCCCCC.toInt())
        gear.textSize = 22f
        gear.gravity = Gravity.CENTER
        gear.setOnClickListener { showMainMenu() }
        tbRow.addView(gear, LinearLayout.LayoutParams(dp(44), dp(44)))

        val order = LinkedHashSet<String>(AppRepo.list(this, Place.TASKBAR))
        WindowController.wins.forEach { order.add(it.app.pkg) }
        if (order.isNotEmpty()) {
            val div = View(this)
            div.setBackgroundColor(0x33FFFFFF)
            val dlp = LinearLayout.LayoutParams(dp(1), dp(24))
            dlp.marginStart = dp(8)
            dlp.marginEnd = dp(8)
            tbRow.addView(div, dlp)
        }
        for (pkg in order) {
            val app = AppRepo.find(this, pkg) ?: continue
            tbRow.addView(taskbarCell(app), LinearLayout.LayoutParams(dp(46), dp(46)))
        }
    }

    private fun taskbarCell(app: AppInfo): View {
        val win = WindowController.wins.find { it.app.pkg == app.pkg }
        val f = FrameLayout(this)
        val iv = ImageView(this)
        iv.setImageDrawable(app.newIcon())
        iv.alpha = if (win != null && win.minimized) 0.55f else 1f
        f.addView(iv, FrameLayout.LayoutParams(dp(28), dp(28), Gravity.CENTER))
        if (win != null) {
            val ind = View(this)
            val d = GradientDrawable()
            d.setColor(0xFF60CDFF.toInt())
            d.cornerRadius = dp(2).toFloat()
            ind.background = d
            val ilp = FrameLayout.LayoutParams(dp(14), dp(3), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
            ilp.bottomMargin = dp(2)
            f.addView(ind, ilp)
        }
        f.setOnClickListener { WindowController.open(this, app) }
        f.setOnLongClickListener {
            val pinned = AppRepo.has(this, Place.TASKBAR, app.pkg)
            val labels = ArrayList<String>()
            val acts = ArrayList<() -> Unit>()
            if (pinned) {
                labels.add("إلغاء التثبيت من شريط المهام")
                acts.add {
                    AppRepo.set(this, Place.TASKBAR, app.pkg, false)
                    WindowController.notifyChange()
                }
            }
            if (win != null) {
                labels.add("تصغير")
                acts.add { WindowController.minimize(win) }
                labels.add("إغلاق")
                acts.add { WindowController.close(win) }
            }
            if (labels.isNotEmpty()) {
                AlertDialog.Builder(this)
                    .setTitle(app.label)
                    .setItems(labels.toTypedArray()) { _, i -> acts[i]() }
                    .show()
            }
            true
        }
        return f
    }

    // ---------------------------------------------------------------- القائمة الرئيسية + اختيار التطبيقات

    private fun showMainMenu() {
        val items = arrayOf(
            "تطبيقات سطح المكتب (إضافة/إزالة)",
            "تطبيقات شريط المهام (إضافة/إزالة)",
            "تغيير الخلفية",
            "الخلفية الافتراضية",
            "إعادة فحص الإعداد"
        )
        AlertDialog.Builder(this)
            .setItems(items) { _, i ->
                when (i) {
                    0 -> pickApps(Place.DESKTOP)
                    1 -> pickApps(Place.TASKBAR)
                    2 -> {
                        val it = Intent(Intent.ACTION_GET_CONTENT).setType("image/*")
                        @Suppress("DEPRECATION")
                        startActivityForResult(it, 7)
                    }
                    3 -> {
                        wallFile.delete()
                        loadBg()
                    }
                    else -> {
                        prefs.edit().putBoolean("ffDone", false).apply()
                        checkSetup()
                    }
                }
            }
            .show()
    }

    private fun pickApps(place: Place) {
        val apps = AppRepo.all(this)
        val cur = AppRepo.list(this, place).toSet()
        val names = apps.map { it.label }.toTypedArray()
        val checked = BooleanArray(apps.size) { cur.contains(apps[it].pkg) }
        AlertDialog.Builder(this)
            .setTitle(if (place == Place.DESKTOP) "تطبيقات سطح المكتب" else "تطبيقات شريط المهام")
            .setMultiChoiceItems(names, checked) { _, i, on -> AppRepo.set(this, place, apps[i].pkg, on) }
            .setPositiveButton("تم", null)
            .setOnDismissListener {
                loadDesk()
                refreshTaskbar()
            }
            .show()
    }

    // ---------------------------------------------------------------- الإعداد

    private fun row(msg: String, btn: String? = null, act: (() -> Unit)? = null) {
        val tv = TextView(this)
        tv.text = msg
        tv.setTextColor(Color.WHITE)
        tv.textSize = 13f
        tv.setPadding(0, dp(6), 0, dp(4))
        card.addView(tv)
        if (btn != null && act != null) {
            val b = Button(this)
            b.text = btn
            b.setOnClickListener { act() }
            card.addView(b)
        }
    }

    private fun checkSetup() {
        card.removeAllViews()
        var ok = true

        if (!Settings.canDrawOverlays(this)) {
            ok = false
            row("1) اسمح بالعرض فوق التطبيقات (لأشرطة عناوين النوافذ وقائمة ابدأ)", "فتح الإعدادات") {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            }
        } else if (OverlayService.instance == null) {
            startForegroundService(Intent(this, OverlayService::class.java))
        }

        val binder = try { Shizuku.pingBinder() } catch (_: Throwable) { false }
        if (!binder) {
            ok = false
            row("2) شغّل تطبيق Shizuku أولاً", "فتح Shizuku") {
                packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")?.let { startActivity(it) }
            }
        } else if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
            ok = false
            row("2) امنح هذا التطبيق صلاحية Shizuku", "منح الصلاحية") { Shizuku.requestPermission(1) }
        } else if (!prefs.getBoolean("ffDone", false)) {
            if (!prefs.getBoolean("ff", false)) {
                WindowController.ensureFreeform()
                prefs.edit().putBoolean("ff", true).apply()
            }
            ok = false
            row("تم تفعيل النوافذ الحرة. إذا لم تعمل النوافذ أعد تشغيل الهاتف مرة واحدة.", "حسناً") {
                prefs.edit().putBoolean("ffDone", true).apply()
                checkSetup()
            }
        }
        card.visibility = if (ok) View.GONE else View.VISIBLE
    }

    // ---------------------------------------------------------------- الخلفية

    private fun loadBg() {
        if (wallFile.exists()) {
            val bmp = BitmapFactory.decodeFile(wallFile.absolutePath)
            if (bmp != null) {
                bg.setImageBitmap(bmp)
                return
            }
        }
        bg.setImageDrawable(
            GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(0xFF021F24.toInt(), 0xFF05796B.toInt(), 0xFF10C9B0.toInt())
            )
        )
    }

    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data
        if (requestCode == 7 && resultCode == RESULT_OK && uri != null) saveWallpaper(uri)
    }

    private fun saveWallpaper(uri: Uri) {
        try {
            val opts = BitmapFactory.Options()
            opts.inJustDecodeBounds = true
            contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
            val max = maxOf(resources.displayMetrics.widthPixels, resources.displayMetrics.heightPixels)
            var s = 1
            while (opts.outWidth / s > max * 2) s *= 2
            val o2 = BitmapFactory.Options()
            o2.inSampleSize = s
            val bmp = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o2) }
            if (bmp != null) {
                FileOutputStream(wallFile).use { bmp.compress(android.graphics.Bitmap.CompressFormat.JPEG, 90, it) }
                loadBg()
            }
        } catch (e: Exception) {
            Toast.makeText(this, "تعذر تحميل الصورة", Toast.LENGTH_SHORT).show()
        }
    }

    // ---------------------------------------------------------------- أيقونات سطح المكتب

    private fun loadDesk() {
        desk.removeAllViews()
        val rows = maxOf(1, (resources.displayMetrics.heightPixels - tbH - dp(24)) / dp(100))
        desk.rowCount = rows
        for (pkg in AppRepo.list(this, Place.DESKTOP)) {
            val app = AppRepo.find(this, pkg) ?: continue
            val c = LinearLayout(this)
            c.orientation = LinearLayout.VERTICAL
            c.gravity = Gravity.CENTER_HORIZONTAL
            c.setPadding(dp(4), dp(6), dp(4), dp(6))
            val iv = ImageView(this)
            iv.setImageDrawable(app.newIcon())
            c.addView(iv, LinearLayout.LayoutParams(dp(46), dp(46)))
            val tv = TextView(this)
            tv.text = app.label
            tv.setTextColor(Color.WHITE)
            tv.textSize = 11f
            tv.maxLines = 2
            tv.gravity = Gravity.CENTER
            tv.setShadowLayer(4f, 0f, 1f, Color.BLACK)
            c.addView(tv, LinearLayout.LayoutParams(-1, -2))
            val glp = GridLayout.LayoutParams()
            glp.width = dp(84)
            glp.height = dp(96)
            c.layoutParams = glp
            c.setOnClickListener { WindowController.open(this, app) }
            c.setOnLongClickListener {
                AlertDialog.Builder(this)
                    .setTitle(app.label)
                    .setItems(arrayOf("إزالة من سطح المكتب")) { _, _ ->
                        AppRepo.set(this, Place.DESKTOP, app.pkg, false)
                        loadDesk()
                    }
                    .show()
                true
            }
            desk.addView(c)
        }
    }
}
