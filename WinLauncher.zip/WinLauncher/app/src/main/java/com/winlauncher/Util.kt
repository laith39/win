package com.winlauncher

import android.content.Context

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

fun Context.sysDimen(name: String): Int {
    val id = resources.getIdentifier(name, "dimen", "android")
    return if (id > 0) resources.getDimensionPixelSize(id) else 0
}

/** clamp آمن لا يرمي استثناء إذا كان الحد الأعلى أصغر من الأدنى. */
fun clampI(v: Int, lo: Int, hi: Int): Int = if (hi < lo) lo else minOf(maxOf(v, lo), hi)

fun Context.dps(v: Int, s: Float): Int = (v * resources.displayMetrics.density * s + 0.5f).toInt()

/** مقاييس الواجهة (1.0 = الافتراضي). مشتركة بين اللانشر وخدمة العرض. */
object Cfg {
    var tb = 1f   // شريط المهام وما عليه
    var dk = 1f   // أيقونات سطح المكتب
    var wb = 1f   // أشرطة عناوين النوافذ
    var mn = 1f   // قائمة ابدأ واللوحات

    fun load(ctx: Context) {
        val p = ctx.getSharedPreferences("win", Context.MODE_PRIVATE)
        tb = p.getFloat("s_tb", 1f)
        dk = p.getFloat("s_dk", 1f)
        wb = p.getFloat("s_wb", 1f)
        mn = p.getFloat("s_mn", 1f)
    }

    fun save(ctx: Context) {
        ctx.getSharedPreferences("win", Context.MODE_PRIVATE).edit()
            .putFloat("s_tb", tb).putFloat("s_dk", dk).putFloat("s_wb", wb).putFloat("s_mn", mn).apply()
    }
}
